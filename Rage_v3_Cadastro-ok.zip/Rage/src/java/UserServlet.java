import java.io.IOException;  
import java.io.PrintWriter;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  
public class UserServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
                  
        HttpSession session=request.getSession(false);  
        if(session!=null){  
            String name=(String)session.getAttribute("name");  

            out.print("<div align='center'><h3 style='background:#dde3ff'>Informações sobre o usuário");  
            out.print("<br>Usuário logado: "+name+"</h3></div>");
        }  
        else{
            out.print("<div align='center'><h3 style='background:#dde3ff'>Usuário não logado!");
            out.print("<br>Por favor, efetue o login!</h3></div>");
            request.getRequestDispatcher("inicio.html").include(request, response);  
        }  
        out.close();  
    }  
}  
/*        if(ck[0].equals("585F76DCBE051918AF9891775AEE00F8") || name.equals("585F76DCBE051918AF9891775AEE00F8")){
        }
        else{
            if(ck!=null){
                name=ck[0].getValue();  
                if(!name.equals("")||name!=null){  
                }
            }else{  
            } 
        }//fecha else
        out.close();  
    }  
}  */