/* Rodrigo Baltazar - CavanhaMan */
package modelo;

public class UserModel {
    private int id;
    private String nome;
    private String senha;
   
    public UserModel(){ }

    public int getId()           {return id;}
    public String getNome()      {return nome;}
    public String getSenha() {return senha;}

    public void setId(int id)                  {this.id = id;}
    public void setNome(String nome)           {this.nome = nome;}
    public void setSenha(String senha) {this.senha = senha;}
}
