import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  

import modelo.UserModel;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

public class LoginServlet extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
 
        String name=request.getParameter("name");  
        String password=request.getParameter("password");  
          
        if(password.equals("123")){ 
            out.print("<div align='center'><h3 style='background:#dde3ff'>Login efetuado com sucesso");
            out.print("<br>Seja bem vindo(a) "+name+"!</h3></div>");  
            HttpSession session=request.getSession();  
            session.setAttribute("name",name);
            request.getRequestDispatcher("inicio.html").include(request, response);
        }  
        else{  
            out.print("<div align='center'><h3 style='background:#dde3ff'>Erro! Usuário ou Senha incorreto!</h3></div>");  
            request.getRequestDispatcher("inicio.html").include(request, response);  
        }  
        out.close();  
    }  
}         
